LD_LIBRARY_PATH=$LD_LIBRARY_PATH:customer/lib_custom/*
/service/ctc2
